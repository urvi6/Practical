//
//  File.swift
//  Urvashi Practical 28 08
//
//  Created by Urvashi on 28/08/23.
//

import Foundation
import UIKit
import Alamofire

class ImageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var imgNumberLBL: UILabel!
    
    // You can define a function to load an image from a URL
    func load(from url: String) {
        if let imageUrl = URL(string: url) {
            imageView.af.setImage(withURL: imageUrl)
        }
    }
}
