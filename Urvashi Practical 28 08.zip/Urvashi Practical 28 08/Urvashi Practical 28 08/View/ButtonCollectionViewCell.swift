//
//  File.swift
//  Urvashi Practical 28 08
//
//  Created by Urvashi on 28/08/23.
//

import Foundation
import UIKit

class ButtonCollectionViewCell: UICollectionViewCell {
  
    @IBOutlet weak var Button: UIButton!
}
