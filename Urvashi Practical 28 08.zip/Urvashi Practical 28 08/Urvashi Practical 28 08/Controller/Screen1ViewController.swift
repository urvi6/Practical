//
//  ViewController.swift
//  Urvashi Practical 28 08
//
//  Created by Urvashi on 28/08/23.
//
import Foundation
import UIKit
import AlamofireImage
import Reachability

//MARK: ----------- Protocol ----------
protocol Screen1Delegate: AnyObject {
    func buttonClicked(withMessage message: String)
}

class Screen1ViewController: UIViewController {
    //MARK: ----------- IBOutlet ----------
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var imgcountTF: UITextField!
    @IBOutlet weak var btncountTF: UITextField!
    @IBOutlet weak var textview: UITextView!
    
    //MARK: ----------- Properties ---------
    var viewModel = ImageViewModel()
    var images: [ImageModel] = []
    let reachability = try! Reachability()
    weak var delegate: Screen1Delegate?
    var imageLocalArray: [UIImage] = []
    var status = 1
    //MARK: ----------- Life Cycle ---------
    override func viewDidLoad() {
        super.viewDidLoad()
      
        do {
            try reachability.startNotifier()
        } catch {
            print("Unable to start Reachability notifier")
        }

        if reachability.connection == .unavailable {
            DispatchQueue.main.async {
                // Show a toast message
                showToast(message: "Network Connection LOST")
                let local = self.fetchImagesFromLocal()
                self.displayImages(local)
//                self.view.makeToast("Network Connection LOST")
            }
        } else if reachability.connection == .cellular {
            status = 1
        }
    }
    
    //MARK: ----------- IBAction ----------
    @IBAction func btnClickOnFetchImages(_ sender: Any) {
        if status == 1 {
            self.fetchImages()
        } else {
            collectionView.reloadData()
        }
    }
    
    @IBAction func btnClickeOnSubmit(_ sender: Any) {
        guard let sizeStr = btncountTF.text, !sizeStr.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              let size = Int(sizeStr) else {
            return showToast(message: "Please enter a valid size")
        }

        if let vc = mainStoryBoard.instantiateViewController(withIdentifier: "Screen2ViewController") as? Screen2ViewController {
            if let text = btncountTF.text, let intValue = Int(text) {
                vc.selectedNumber = intValue
            }
            vc.delegate = self
            btncountTF.text = ""
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    //MARK: ----------- User Defaults Funcation -------
    func fetchImages() {
        if let text = imgcountTF.text, let intValue = Int(text) {
            
            viewModel.fetchImages(size: intValue) { [weak self] result in
                switch result {
                case .success(let images):
                    print("\(images) images")
                    //                    saveImagesLocally(images: images)
                    self?.images = images
                    self?.collectionView.reloadData()
                case .failure(let error):
                    print("Error fetching images: \(error)")
                }
            }
        }
    }
    
    func fetchImagesFromLocal() -> [UIImage] {
        var images: [UIImage] = []
        let fileManager = FileManager.default
        let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!

        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsDirectory, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
            for fileURL in fileURLs {
                if let imageData = try? Data(contentsOf: fileURL),
                   let image = UIImage(data: imageData) {
                    images.append(image)
                }
            }
        } catch {
            print("Error fetching images from local storage: \(error)")
        }

        return images
    }
    func displayImages(_ images: [UIImage]) {
           for image in images {
               print("\(image) images")
               status = 0
               imageLocalArray.append(image)
           }
       }
    //MARK: ----------- UITextRange Delegate -------
    func shouldChangeCharacters(in range: UITextRange, replacementString string: String) -> Bool {
        let allowedCharacters = CharacterSet(charactersIn: "0123456789")
        let characterSet = CharacterSet(charactersIn: string)
        return allowedCharacters.isSuperset(of: characterSet)
    }
}

//MARK: ----------- UICollectionViewDataSource ---------
extension Screen1ViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if status == 1 {
            return images.count
        }
        if let text = imgcountTF.text, let intValue = Int(text) {
            
            return intValue
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // Implement cell configuration based on your ImageModel
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionViewCell", for: indexPath) as! ImageCollectionViewCell
        if status == 1 {
            let imageModel = images[indexPath.item]
            cell.load(from: imageModel.image_url)
            cell.imgNumberLBL.text = "\(indexPath.item + 1)"
        } else {
            let imageModel = imageLocalArray[indexPath.item]
            cell.imageView.image = imageModel
            cell.imageView.layer.borderWidth = 2
            cell.imageView.layer.borderColor = UIColor.red.cgColor
            cell.imgNumberLBL.text = "\(indexPath.item + 1)"
        }
        
        return cell
    }
}

//MARK: ----------- Screen1Delegate ---------
extension Screen1ViewController: Screen1Delegate {
    func buttonClicked(withMessage message: String) {
        // Display the message in a text view
        textview.text = message
        print("\(message) ...........")
    }
}
