//
//  Screen2ViewController.swift
//  Urvashi Practical 28 08
//
//  Created by Urvashi on 28/08/23.
//

import UIKit

class Screen2ViewController: UIViewController {
    //MARK: ----------- IBOutlet ----------
    @IBOutlet weak var btnclcView: UICollectionView!
    
    //MARK: ----------- Properties ---------
    var selectedNumber: Int = 0
    weak var delegate: Screen1Delegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
//MARK: ----------- UICollectionViewDataSource ---------
extension Screen2ViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return selectedNumber
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // Implement cell configuration based on your ImageModel
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ButtonCollectionViewCell", for: indexPath) as! ButtonCollectionViewCell
        cell.Button.setTitle("Button \(indexPath.row + 1)", for: .normal)
        cell.Button.addTarget(self, action: #selector(backOnScreen1), for: .touchUpInside)
        cell.Button.tag = indexPath.row + 1
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Set the width and height for each cell
        let width = UIScreen.main.bounds.width
        return CGSize(width: width / 4, height: 100)
    }
    
    @objc func backOnScreen1(_ sender: UIButton) {
        let message = "You have clicked button \(sender.tag)"
        delegate?.buttonClicked(withMessage: message)
        self.navigationController?.popViewController(animated: true)
        
    }
}
