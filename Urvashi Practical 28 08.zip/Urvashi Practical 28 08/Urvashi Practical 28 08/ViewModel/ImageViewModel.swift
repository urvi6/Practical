//
//  ImageViewModel.swift
//  Urvashi Practical 28 08
//
//  Created by Urvashi on 28/08/23.
//

import Foundation
import Alamofire
import AlamofireImage


class ImageViewModel {
    private let baseUrl = "http://staging-server.in/android-task/api.php"
    
    func fetchImagess(size: Int, completion: @escaping (Result<[ImageModel], Error>) -> Void) {
        let parameters: [String: Any] = ["size": size]
        
        AF.request(baseUrl, method: .get, parameters: parameters)
            .validate()
            .responseJSON { response in
                switch response.result {
                case .success(let value):
                    do {
                        // Parse the JSON response as a dictionary
                        if let json = value as? [String: Any],
                           let data = json["data"] as? [[String: String]] {
                            // Convert the dictionary to ImageModel objects
                            
                            let images = data.map { dict in
                                downloadAndSaveImage(from: dict["image_url"] ?? "") { result in
                                    switch result {
                                    case .success(let savedImageUrl):
                                        print("Image saved at: \(savedImageUrl)")
                                        
                                        // Handle the saved image URL as needed
                                    case .failure(let error):
                                        print("Error downloading image: \(error)")
                                        // Handle the error
                                    }
                                }
                                return ImageModel(image_url: dict["image_url"] ?? "")
                            }
                            //                            deleteAllImage()
                            completion(.success(images))
                        } else {
                            completion(.failure(NSError(domain: "Invalid Response", code: -1, userInfo: nil)))
                        }
                    } catch {
                        print("Error decoding JSON: \(error)")
                        completion(.failure(error))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
    func fetchImages(size: Int, completion: @escaping (Result<[ImageModel], Error>) -> Void) {
        let parameters: [String: Any] = ["size": size]
        
        AF.request(baseUrl, method: .get, parameters: parameters)
            .validate()
            .responseJSON { response in
                switch response.result {
                case .success(let value):
                    do {
                        // Parse the JSON response as a dictionary
                        if let json = value as? [String: Any],
                           let data = json["data"] as? [[String: String]] {
                            // Create an array to hold the downloaded image URLs
                            var downloadedImageURLs = [URL]()
                            
                            // Use a DispatchGroup to wait for all downloads to complete
                            let downloadGroup = DispatchGroup()
                            
                            for dict in data {
                                downloadGroup.enter()
                                let imageUrl = dict["image_url"] ?? ""
                                downloadAndSaveImage(from: imageUrl) { result in
                                    switch result {
                                    case .success(let savedImageUrl):
                                        // Append the saved image URL to the array

                                        downloadedImageURLs.append(savedImageUrl)
                                        
                                    
                                        downloadGroup.leave()
                                    case .failure(let error):
                                        print("Error downloading image: \(error)")
                                        downloadGroup.leave()
                                    }
                                }
                            }

                            // Notify when all downloads are complete
                            downloadGroup.notify(queue: .main) {
                                // Create ImageModel objects with the downloaded image URLs
                                let images = downloadedImageURLs.map { url in
                                    return ImageModel(image_url: url.absoluteString)
                                }
                                completion(.success(images))
                            }
                        } else {
                            completion(.failure(NSError(domain: "Invalid Response", code: -1, userInfo: nil)))
                        }
                    } catch {
                        print("Error decoding JSON: \(error)")
                        completion(.failure(error))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
}
func downloadAndSaveImage(from imageUrl: String, completion: @escaping (Result<URL, Error>) -> Void) {
    guard let url = URL(string: imageUrl) else {
        completion(.failure(NSError(domain: "Invalid URL", code: -1, userInfo: nil)))
        return
    }
    
    let destination: DownloadRequest.Destination = { _, _ in
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        print("\(documentsDirectory) documentsDirectory")
        let fileURL = documentsDirectory.appendingPathComponent(UUID().uuidString + ".png")
        return (fileURL, [.removePreviousFile, .createIntermediateDirectories])
    }
    
    AF.download(url, to: destination).response { response in
        switch response.result {
        case .success(let url):
            completion(.success(url!))
        case .failure(let error):
            completion(.failure(error))
        }
    }
}

