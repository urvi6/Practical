//
//  ImageModel.swift
//  Urvashi Practical 28 08
//
//  Created by Urvashi on 28/08/23.
//

import Foundation
import UIKit

struct ImageModel: Codable {
    // Define properties based on your API response
    // For example, if your API returns URLs to images, you might have a property like this:
    let image_url: String
    
}
