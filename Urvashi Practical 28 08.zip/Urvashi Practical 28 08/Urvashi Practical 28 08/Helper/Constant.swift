//
//  Constant.swift
//  Urvashi Practical 28 08
//
//  Created by Urvashi on 28/08/23.
//

import Foundation
import UIKit
import Toast

let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)

func showToast(message: String) {
    DispatchQueue.main.async {
        let windows = UIApplication.shared.windows
        windows.last?.makeToast(message)
    }
}
